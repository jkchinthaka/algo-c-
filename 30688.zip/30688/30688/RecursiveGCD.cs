﻿using System;

namespace _30688
{
    internal class RecursiveGCD
    {
        static void Main(string[] args)
        {
            // Example numbers
            int num1 = 120;
            int num2 = 35;

            // Compute GCD
            int result = GCD(num1, num2);

            // Display result
            Console.WriteLine($"GCD({num1}, {num2}) = {result}");
        }

        // Recursive GCD method
        public static int GCD(int num1, int num2)
        {
            if (num2 == 0)
                return num1;
            return GCD(num2, num1 % num2);
        }
    }
}
