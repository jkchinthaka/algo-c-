﻿using System;

namespace _33688
{
    internal class FactorialFinder
    {
        // Recursive factorial method
        public long RecursiveFactorial(int number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Factorial is not defined for negative numbers.");
            }
            if (number == 0 || number == 1)
            {
                return 1;
            }
            return number * RecursiveFactorial(number - 1);
        }

        // Iterative factorial method
        public long IterativeFactorial(int number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Factorial is not defined for negative numbers.");
            }
            long result = 1;
            for (int i = 1; i <= number; i++)
            {
                result *= i;
            }
            return result;
        }

        // Recursive Fibonacci method
        public long RecursiveFibonacci(int n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Fibonacci is not defined for negative numbers.");
            }
            if (n <= 1)
            {
                return n;
            }
            return RecursiveFibonacci(n - 1) + RecursiveFibonacci(n - 2);
        }
    }
}
