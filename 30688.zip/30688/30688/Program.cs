﻿using System;

namespace _30688
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*");
            Console.WriteLine("Recursion and Iteration");

            // Create an instance of FactorialFinder
            FactorialFinder factorialFinder = new FactorialFinder();

            // Display menu options
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1. Calculate Factorial");
            Console.WriteLine("2. Calculate GCD");
            Console.Write("Enter your choice (1 or 2): ");

            // Read user choice
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    // Factorial calculation
                    Console.WriteLine("Choose a method to calculate factorial:");
                    Console.WriteLine("1. Recursive");
                    Console.WriteLine("2. Iterative");
                    Console.Write("Enter your choice (1 or 2): ");

                    // Read user choice for factorial method
                    string factorialChoice = Console.ReadLine();

                    Console.Write("Enter a number: ");
                    string inputFromUser = Console.ReadLine();
                    int number;

                    // Try to parse the user input
                    if (!int.TryParse(inputFromUser, out number) || number < 0)
                    {
                        Console.WriteLine("Invalid input. Please enter a non-negative integer.");
                        break;
                    }

                    // Handle the user's choice for factorial method
                    switch (factorialChoice)
                    {
                        case "1":
                            // Calculate factorial using recursion
                            long recursiveResult = factorialFinder.RecursiveFactorial(number);
                            Console.WriteLine($"RecursiveFactorial({number}) is {recursiveResult}");
                            break;
                        case "2":
                            // Calculate factorial using iteration
                            long iterativeResult = factorialFinder.IterativeFactorial(number);
                            Console.WriteLine($"IterativeFactorial({number}) is {iterativeResult}");
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please enter 1 or 2.");
                            break;
                    }
                    break;

                case "2":
                    // GCD calculation
                    Console.Write("Enter the first number: ");
                    string inputA = Console.ReadLine();
                    Console.Write("Enter the second number: ");
                    string inputB = Console.ReadLine();

                    int a, b;

                    // Try to parse the user inputs
                    if (!int.TryParse(inputA, out a) || !int.TryParse(inputB, out b) || a < 0 || b < 0)
                    {
                        Console.WriteLine("Invalid input. Please enter non-negative integers.");
                        break;
                    }

                    // Calculate GCD using recursion
                    int gcdResult = factorialFinder.RecursiveGCD(a, b);
                    Console.WriteLine($"GCD({a}, {b}) is {gcdResult}");
                    break;

                default:
                    Console.WriteLine("Invalid choice. Please enter 1 or 2.");
                    break;
            }

            Console.WriteLine("*");
        }
    }

    internal class FactorialFinder
    {
        // Recursive factorial method
        public long RecursiveFactorial(int n)
        {
            if (n <= 1)
                return 1;
            else
                return n * RecursiveFactorial(n - 1);
        }

        // Iterative factorial method
        public long IterativeFactorial(int n)
        {
            long result = 1;
            for (int i = 1; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        // Recursive GCD method
        public int RecursiveGCD(int a, int b)
        {
            if (b == 0)
                return a;
            else
                return RecursiveGCD(b, a % b);
        }
    }
}
